# SynQc integration guide

This adapter bundles the `dual_clocking` simulator into a single zip so the SynQc
TDS hybrid controller can load it without a build step.

## Creating a drop-in bundle

```bash
python -m synqc_adapter.bundler /tmp/dual_clocking_synqc.zip
# include CLI examples for quick smoke tests
python -m synqc_adapter.bundler /tmp/dual_clocking_synqc_with_examples.zip --include-examples
# override manifest and package versions to match controller expectations
python -m synqc_adapter.bundler /tmp/dual_clocking_synqc_v2.zip --version 0.2.0 --manifest-version 2
```

Each archive contains:

- `dual_clocking` and `synqc_adapter` packages
- `requirements.txt` and `README.md` for dependency/application context
- `synqc_manifest.json` recording the entrypoint and available backends

## Using inside the controller

1. Place the generated zip where the SynQc tool loader expects drop-ins.
2. Add the archive to `PYTHONPATH` (or unzip alongside other tools).
3. Import and drive the facade:

```python
from synqc_adapter import SynQcDualClockingTool

tool = SynQcDualClockingTool(
    backend="superconducting",
    backend_options={"drive_frequency": 5.0, "readout_frequency": 6.5, "dt": 1e-9},
)

schedule_result = tool.build_schedule({"t_probe": 20e-9, "two_tone": True})
simulation = tool.simulate({"t_probe": 20e-9, "two_tone": True}, shots=64)
```

`synqc_manifest.json` declares `synqc_adapter.tool:SynQcDualClockingTool` as the
entrypoint and enumerates builtin backends. The controller can parse this file to
route configuration to the correct adapter.

## Notes and recommended next steps

- Run `python -m pytest tests` before packaging to confirm simulations remain stable.
- If the controller prefers alternative manifest fields, extend
  `SynQcManifest` in `synqc_adapter/bundler.py` to match the desired schema.
- For production use, wire a dependency installer in the SynQc loader to satisfy
  `requirements.txt` prior to import.
- GitHub Actions workflow `.github/workflows/synqc-bundle.yml` builds and uploads
  fresh archives on releases; use the artifacts as ready-to-drop zips.
