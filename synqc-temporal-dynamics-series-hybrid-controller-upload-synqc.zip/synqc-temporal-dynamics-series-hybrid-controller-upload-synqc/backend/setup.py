from setuptools import setup, find_packages

setup(
    packages=find_packages(include=['synqc_backend', 'synqc_backend.*']),
)
