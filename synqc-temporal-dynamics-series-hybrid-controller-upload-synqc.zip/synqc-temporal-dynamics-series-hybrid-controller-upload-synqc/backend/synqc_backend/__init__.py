"""SynQc Temporal Dynamics Series Backend (v0.1).

Provides the FastAPI app, engine, and models used by the SynQc TDS console.
"""