from __future__ import annotations

from .settings import SynQcSettings, settings  # re-export for backward compatibility

__all__ = ["SynQcSettings", "settings"]
