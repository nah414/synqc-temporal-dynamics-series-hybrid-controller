"""
dcq — Minimal stubs for Dual‑Clocking tests.
This is a tiny shim to exercise properties described in the roadmap.
"""
