from __future__ import annotations
import math, random
from typing import Tuple

def rabi_error(amplitude: float, drift: float) -> float:
    "Toy error model: convex around amplitude=1.0; drift adds bias."
    return (amplitude - 1.0 + drift)**2 + 1e-4

def gradient_descent(init_amp: float, drift: float, steps: int = 50, lr: float = 0.1) -> Tuple[float, float]:
    "Minimize rabi_error by gradient descent; returns (amp, error)."
    a = init_amp
    for _ in range(steps):
        # d/da ( (a-1+d)^2 ) = 2*(a-1+d)
        grad = 2.0*(a - 1.0 + drift)
        a -= lr*grad
    return a, rabi_error(a, drift)
