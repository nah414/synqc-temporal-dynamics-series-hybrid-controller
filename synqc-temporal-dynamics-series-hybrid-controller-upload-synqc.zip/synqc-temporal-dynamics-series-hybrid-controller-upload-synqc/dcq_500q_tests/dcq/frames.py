from __future__ import annotations

def unitary_distance(u1, u2) -> float:
    """
    Frobenius-like distance between 2x2 complex matrices given as tuples of tuples.
    """
    import cmath
    s = 0.0
    for i in range(2):
        for j in range(2):
            d = u1[i][j] - u2[i][j]
            s += (d.real**2 + d.imag**2)
    return s ** 0.5

def x90_frame_equivalence(phase1: float, phase2: float) -> float:
    """
    Compare X/2 rotations executed on two frames that differ by a Z-phase.
    Ideal equivalence: up to a global phase, they match; distance ~ 0.
    """
    import cmath, math
    # X/2 = cos(pi/4) I - i sin(pi/4) X; Z-phase rotates frame: Rz(phi) X Rz(-phi)
    c = (2**0.5)/2.0
    I = ((1+0j,0+0j),(0+0j,1+0j))
    X = ((0+0j,1+0j),(1+0j,0+0j))
    # Effective op on frame with phase phi: U_phi = Rz(phi) * X/2 * Rz(-phi)
    def rz(phi):
        return ((cmath.exp(-1j*phi/2),0),(0, cmath.exp(1j*phi/2)))
    def matmul(a,b):
        return tuple(tuple(sum(a[i][k]*b[k][j] for k in range(2)) for j in range(2)) for i in range(2))
    def scalarmul(s,m): return tuple(tuple(s*m[i][j] for j in range(2)) for i in range(2))
    x90 = scalarmul(c, ((1+0j,-1j,),( -1j,1+0j)))
    # Note: quick construction; only relative comparison matters
    U1 = matmul(matmul(rz(phase1), x90), rz(-phase1))
    U2 = matmul(matmul(rz(phase2), x90), rz(-phase2))
    return unitary_distance(U1, U2)
