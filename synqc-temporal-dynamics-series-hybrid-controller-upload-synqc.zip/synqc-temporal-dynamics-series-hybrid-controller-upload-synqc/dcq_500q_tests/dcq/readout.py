from __future__ import annotations
from typing import List

def total_power_dbm(tones_dbm: List[float]) -> float:
    """
    Sum RF powers in dBm correctly (linear domain, then convert back).
    """
    import math
    linear = sum(10**(p/10.0) for p in tones_dbm)
    return 10.0*math.log10(max(linear, 1e-15))
