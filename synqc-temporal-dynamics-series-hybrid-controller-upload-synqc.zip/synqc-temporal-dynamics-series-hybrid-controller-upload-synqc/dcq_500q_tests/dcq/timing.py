from __future__ import annotations
from typing import Dict

def residual_skew_ps(cal_map_ps: Dict[str, int]) -> int:
    "Return peak-to-peak skew in picoseconds from a per-channel calibration map."
    if not cal_map_ps:
        return 0
    vals = list(cal_map_ps.values())
    return max(vals) - min(vals)
