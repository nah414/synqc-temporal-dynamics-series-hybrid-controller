# DCQ 500‑Q Test Bundle (v0.1)

This lightweight pytest suite backs key data findings/claims in the roadmap:
- Deterministic scheduling (event table hash stays stable)
- Neighbor frequency separation by allocator
- Calibration loop convergence under drift (toy model)
- Dual-frame gate equivalence (X/2 on different frames)
- Readout mux power budgeting
- Timing skew accounting

## Run
```bash
pip install pytest
pytest -q
```
