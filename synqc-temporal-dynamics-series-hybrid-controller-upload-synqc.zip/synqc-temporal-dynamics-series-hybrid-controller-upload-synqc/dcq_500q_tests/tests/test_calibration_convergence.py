from dcq.cal_sim import gradient_descent, rabi_error

def test_rabi_converges_under_drift():
    amp0 = 0.5
    drift = 0.05
    amp, err = gradient_descent(amp0, drift, steps=100, lr=0.2)
    # Should get close to amplitude ~ 0.95 (1 - drift) and small error
    assert abs(amp - (1.0 - drift)) < 1e-2
    assert err < 1e-3
