from dcq.scheduler import build_schedule, canonical_hash

def test_schedule_hash_deterministic():
    reqs = [
        {"chan":"Q0.XY","op":"X90","dur_samples":16,"island":"I0"},
        {"chan":"Q1.XY","op":"X","dur_samples":32,"island":"I0"},
        {"chan":"Q0.RO","op":"MEAS","dur_samples":64,"island":"I0"},
    ]
    resources = {"I0": 64}
    e1 = build_schedule(reqs, resources)
    e2 = build_schedule(list(reqs), dict(resources))  # new objects, same content
    assert canonical_hash(e1) == canonical_hash(e2)
