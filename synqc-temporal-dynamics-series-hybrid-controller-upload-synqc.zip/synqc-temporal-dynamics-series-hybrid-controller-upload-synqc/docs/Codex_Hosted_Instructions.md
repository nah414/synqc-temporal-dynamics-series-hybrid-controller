(Included in the zip pack link above — instructions you can paste into Codex.)
